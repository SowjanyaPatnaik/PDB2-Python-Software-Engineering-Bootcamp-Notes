import mod1

mod1.foo()