__all__ = ['foo']

def foo():
    from pkg import a
    print(a)
    print('[mod1] foo()')

class Foo:
    pass


"""
create a maths_problem package
create a module for fibonacci series
create a module for factorial
create a module for amstrong number

from maths_problem import fibonacci
r =fib(10)



"""