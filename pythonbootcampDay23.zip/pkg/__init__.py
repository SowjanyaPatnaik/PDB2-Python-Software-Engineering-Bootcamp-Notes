print(f'Invoking __init__.py for {__name__}')
a = ['quux','corge','grault']

__all__ = [
    'mod1',
    'mod2'
]