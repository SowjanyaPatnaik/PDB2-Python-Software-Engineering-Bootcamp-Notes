"""
Module - a set of code for the functionality segment

It meant for code reusability, maintenance, scoping and simplicity

Module can be written in python itself, or builtin module like itertools, operator,
written in C and DLL


write an module called Calculator and def add, sub, div, mul

try below with uncomment and comment
if __name__ = "__main__":
   add,sub,div,mul

python calculator.py

creat an another file called "calc_test.py"

import calculator
add,sub,div,mul

"""

# s = "Hello"
# a = [100, 200, 300]
#
#
# def foo(arg):
#     print(f'arg={arg}')
#
#
# class Foo:
#     pass
#
#
# if __name__ == "__main__":
#     print("I'm executing mod")