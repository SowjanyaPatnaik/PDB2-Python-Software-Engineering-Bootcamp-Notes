def add(*args,**kwargs):
    return sum(args) + sum(kwargs.values())
