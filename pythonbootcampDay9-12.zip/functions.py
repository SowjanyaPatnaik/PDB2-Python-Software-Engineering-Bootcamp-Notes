# """
# functions - ?
#
# a function is a block of code which will perform specific task
# """
#
# # #function definition
# # def sum():
# #     print(2+2)
# #
# # #function calling
# # a = sum()
# # print("sum is,", a)
# #
# #
# # #argument, keyword arguments
# # def sum(a,b):
# #     return a+b
# #
# # s = sum(2,3)
# # print("The sum of 2 and 3 is ",s)
# #
# # s = sum(a=2,b=3)
# # print("The sum of 2 and 3 is ",s)
# #
#
# def get_input():
#     a = int(input("enter the first number:"))
#     b = int(input("enter the seconde number:"))
#     print(a,b)
#     return a,b
#
# def sum_of_inputs():
#     a,b = get_input()
#     print(a+b)
#     # return a+b
#
# s1 = sum_of_inputs()
# print(s1)
#
#
# ##function with arguments
# """
# def <function_name>(param1,param2,...paramn)
# """
#
# def sum(a,b,c):
#     return a+b+c
#
# print(sum(2,234,23)




# def sum(a,b):
#     return a+b
#
# def sum(a,b,c=0):
#     return a+b+c
#
# a = sum(2,3)

##principle: the positional argument must come before keyword argumnents
def sum_of_n(first_number,second_number,*args,**kwargs):
    print("first_number is",first_number)
    print("second_number is",second_number)
    print("args is",args)
    print("kwargs is",kwargs)
    sum = 0
    for each in args:
        sum += each
    for each in kwargs:
        sum += kwargs[each]
    # print(sum)
    return sum
# a = sum_of_n(2,3,4,5,6,7,8,9,10,11,12,13,14,15,z=29,y=30)
# print(a)
# b = sum_of_n(5,2,3,4,5,a=2,b=9)
b = sum_of_n(4,2,32,343,234,234,a=2,b=3,c=4)
print(b)

#send_email(subjet,to,cc,bcc)

#func to concat any number of words given
"""
concat("is","this","the","right","time")
is this the right time

concat("how","are","you")
how are you

contact(str1="Hi,",str2="Hello")
Hi, Hello

concat("Hello",greetings="Welcome to the bootcamp")
Hello, welcome to the bootcamp
"""


"""
factorial of a number - 3
6

define a function for the factorial of n
"""

def factorial(n):
    """
    factorial of the given number n

    :param n: int
    :return: factorial of n
    """
    output = 1
    while n > 0:
        output = output * n
        n = n - 1
    return output

fact = factorial
print(f'the factorial of 999 is {fact(999)}')

"""recursive function - calling the function on it's own"""

def recur_factorial(n):
    if n == 1:
        return n
    else:
        return n*recur_factorial(n-1)

print(f'the factorial of 10 is {recur_factorial(10)}')

"""
n = 10

n==1 False
10*recur_factorial(9)
10*9*recur_factorial(8)
10*9*8*recur_factorial(7)
....
10*9*8*7*6*5*4*3*2*1
"""

"""
write a program to reverse the string using recursion
"""

"""
write a fibonacci series using recursion

fib(2)

1
"""

"""
scope of variables in python
L E G B - order of precedence of scope

L - Local
E - Enclosed
G - Global
B - Built in
"""


v1 = 100
print(v1) #--> 100
def printobj1():
    print(v1)
printobj1() #--> 100

def printobj2():
    global v1
    v1 = 200
    print(v1)

print(v1) #--> 100
printobj2() #--> 200
print(v1) #--> 100

#closure design pattern which is nothing defining an function within the function

def test():
    a = 100

    def test1():
        nonlocal a
        a = a + 200
        print(a)

    print(a)
    test1()
    print(a)

test()

"""
builtin namespace
global namespace
local namespace
"""

var1 = 5 ## --> Global
def func1():
    var2 = 6 ## --> local
    def inner_func1():
        var3 = 7 ## --> nested local or enclos
        return var3
    var3 = inner_func1()

def some_func():
    print("Inside some func")
    def some_inner_func():
        var = 10
        print("inside inner function, value of var:",var)
        return var
    var=some_inner_func()
    print("try printing var from outer function: ",var)
some_func()


str1 = "sugumar"
def test_str_call(s):
    s =  s + "venkatesan"
    return s

print(str1)
print(test_str_call(str1))
print(str1)

l = [1,2,3]
def test_list_call(l):
    l.append(5)

print(l)
test_list_call(l)
print(l)

import copy
i = [4,5,6]
def test_list_call1(i):
    i = copy.copy(i)
    i.append(7)
    print(i)
print(i)
test_list_call1(i)
print(i)


a = ["apple","banana"]
b = copy.copy(a)
a.append("biscuits")
print(id(a))
print(id(b))
print(a)
print(b)

# a = ["apple"]

"""
Bagels - game is to guess the number and win it

computer: 897 (random). random.randint(100,999)

human 1: 123 -> nothing is right
      2: 483 -> one digit is right but with wrong position
      3: 983 -> two digit is right but with wrong position
      4: 978 -> three digit is right but with wrong position
      5: 879 -> one digit is right and other two digits with wrong position
      6: 897 -> You won it.
      
generate_random_number()
get_user_input()
evaluate_user_input()

main()
    10 guesses condition here
    generate_random_number()
    get_user_input()
    evaluate_user_input()
  
"""