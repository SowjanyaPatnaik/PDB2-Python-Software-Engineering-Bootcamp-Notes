# # #custom exception in python
# # class Error(Exception):
# #     pass
# #
# # class ValueTooSmallError(Error):
# #     def __init__(self,n):
# #         self.n = n
# #         super().__init__(self.n)
# #
# # class ValueTooLargeError(Error):
# #     pass
# #
# # number = 10
# #
# # while True:
# #     try:
# #         i_num = int(input("Enter a Number: "))
# #         if i_num < number:
# #             raise ValueTooSmallError(i_num)
# #         elif i_num > number:
# #             raise ValueTooLargeError
# #         break
# #     except ValueTooSmallError as e:
# #         print("The Value is too small, try again", e)
# #     except ValueTooLargeError:
# #         print("The Value is too large, try again")
# #
# # print("Congratulations! you guessed it correctly.")
# #
# #
#
#
# # class SalaryNotInRangeError(Exception):
# #     def __init__(self,salary,message="salary is not in (5000,15000) range"):
# #         self.salary = salary
# #         self.message = message
# #         super().__init__(self.message)
# #
# # salary = int(input("enter salary amount: "))
# # if not 5000 < salary < 15000: #if not salary > 15000 and not salary < 5000:
# #     raise SalaryNotInRangeError(salary)
#
#
# ###write a program to find the count of elements in the list
# """
# a = [2,2,4,7,8,4,7,9,10,9,21,32]
#
# {2:2,4:2,7:2,8:1,9:2,10:1,21:1,32:1}
#
# hint: if, dicionary (key check), update dictionary
# """
#
#
# #### input of age, and if it's less than 18 raise an custom exception
# ### saying NotEligibleAgeOfAdult
#
# a = [2,2,4,7,8,4,7,9,10,9,21,32]
#
# r = {}
# for each in a:
#     if each in r.keys():
#         r[each] = r[each] + 1
#     else:
#         r[each] = 1
# print(r)

a=[2,2,4,7,8,4,7,9,10,9,21,32]
for i in a:
 my_dict = {i:a.count(i)}

print(my_dict)