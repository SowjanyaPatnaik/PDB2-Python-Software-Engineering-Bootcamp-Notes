"""
python is both functional and object oriented programming language

OOPS - representing the coding in terms of real world and it can be resuable

once defined we could reuse it anywhere.

classes, methods and objects

Class - A class is a blueprint for the objects. The class can define the common attributes and
behaviour of all the objects

Fruit Class - Apples, Banana, Kiwi, etc.,
Bird - Pigeon, eagle,


Objects - An objects ia an entity that has attributes and behaviour. For example, The Apple object of Fruit
class will have the attributes like color, shape and certain behaviours rich in vitamin, benefit

inheritance, polymorphism, abstraction and encapsulation.

"""

class Human:
    def __init__(self):
        pass


h1 = Human()
print(h1, type(h1))

#constrcutor - constructor is an form of calling the objects attributes or initializing the object in the runtime

class Human:
    def __init__(self,name,height,weight):
        self.name = name
        self.weight = weight
        self.height = height

    def eating(self,food):
        return "{} is eating {}".format(self.name,food)

ram = Human("Ram",7,89)
print(ram.height,ram.weight,ram.name)
print(ram.eating("Pizza"))

"""
write a class Fruit, and give attributes and methods
"""

class DemoClass:
    num = 100

    def __init__(self):
        self.num = 199

    def read_number(self):
        print(self.num)

obj = DemoClass()
obj.read_number()


"""
create a class Calculator - 2 variable a and b

add, sub, mul, div

"""

class Calculator:
    def __init__(self,first_number,second_number):
        self.a = first_number
        self.b = second_number

    def addition(self):
        return self.a + self.b

    def multiplication(self):
        return self.a * self.b

    def subtraction(self):
        return abs(self.a - self.b)

    def division(self):
        return self.a / self.b

cal1 = Calculator(8,9)
print(cal1.addition(),cal1.multiplication(),cal1.subtraction(),cal1.division())

"""
given an array of size N-1 such that it only contains distinct integers in the range of 1 to N. find the
missing element
a = [1,5,3,2]
a  = [6,1,2,8,3,4,7,10,5]

abs(sum(range(min(a),max(a)+1) - sum(a))

Vehicle parking system in python
Trees using Class - Binary Tree, BST
Abstraction, Polymorphism, inheritance and encapsulation.
"""

"""