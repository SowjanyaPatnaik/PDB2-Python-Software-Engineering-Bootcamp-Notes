"""
lambda - anonymous function in python
map
filter
reduce
"""

"""
lambda arguments: expression
"""

def square(n):
    return n ** 2
print(square(5))

squareL = lambda n: n**2
print(squareL(5))

maxi = lambda x,y: x if x > y else y
print(maxi(4,8))

def transform(n):
    return lambda x: x+n
f = transform(4)
print(f(9))

#lambda for sorting sort(4,5): (5,4), sort(9,6): (9,6)

#a = [2,3,4,5], using lambda and comprehension,make the cube of the numbers
#def cube, write a lambda for that cube - [8,27,64,125]
#
# def cube(n):
#     return n ** 3

a = [2,3,4,5]
cube = lambda n: n**3
output = [ cube(each) for each in a ]
print(output)

output2 = []
for each in a:
    output2.append(each**3)
print("output2",output)

def cube(n):
    return n ** 3
cubes = map(cube,a) #map(expression, iterable)
print("cubes",list(cubes))

num1 = [2,4,9]
num2 = [3,8,5]
result = map(lambda x,y: x+y, num1,num2)
print(list(result))

###["1","2","3","4"] -> map to convert in to int [1,2,3,4]
r = ["1","2","3","4"]
s = map(int,r)
print(list(s))

c = map(lambda x:x**3, [1,2,3])
print(list(c))

"""
data = [{"firstname":"test","lastname":"test1"}, {"firstname":"test3","lastname":"test4"}]

output = ["test, test1","test3, test4"]

? comprehension -> [ each['firstname'] + "," + each["lastname"]  for each in data ]
  map with lambda -> map(lambda x:x['firstname'] + ", " + x['lastname'], data])
  map with regular function 
  
  def get_firstname_lastname(data1):
        return data1["firstname"] + ", " + data1["lastname"]
  res = map(get_firstname_lastname, data)
"""

"""
filter, reduce
"""

nums = [1,34,23,56,89,44,92]
odd_nums = [num for num in nums if num % 2 != 0]
print("odd_nums",odd_nums)

def find_odd(x):
    if x % 2 != 0:
        return x
odds = filter(find_odd,nums)
print("odds",list(odds))

odds2 = filter(lambda x:x %2 != 0, nums)
print("odds2",list(odds2))

nums = [1,2,3,4,5]
#sum of numbers in the list
total = 0
for i in nums:
    total =  total + i
print("total",total)

from functools import reduce
total2 = reduce(lambda x,y: x+y, nums) #((((1+2)+3)+4)+5)
print("total2",total2)

#millions of employees record in the database, how many total leaves are taken by each employee

"""
data = [
   {"name":"sugumar","subject":"maths","marks":78,"total":"100"},
   {"name":"sugumar","subject":"science","marks":88,"total":"100"},
   {"name":"sugumar","subject":"english","marks":90,"total":"100"}
]

calculate grades 70 - 80 - 7A, 80 - 90 - 8A, 90-100 - 9A
calcuate percentage 
sort the data by the percetnage - lambda 
"""