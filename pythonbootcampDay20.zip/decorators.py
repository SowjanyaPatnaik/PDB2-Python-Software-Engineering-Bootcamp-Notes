"""
decoratos - help to add functionality to an existing code.

Sum - implemented

extend the function without changing its implementation, then we will use decorators

"""

def first(msg):
    print(msg)

first("hello")

second = first
second("hello")

third = first
third("hello3")

def inc(x):
    return x + 1

def dec(x):
    return x -1

def operate(func,x):
    result = func(x)
    return result

print(operate(inc,5))
print(operate(dec,6))

def is_called():
    def is_returned():
        print("Hello")
    return is_returned

new = is_called()
print(new())

"""
function objects can hold different names - different variables can be assigned to the same function
we could pass function as an argument to another function
we could return an function from another function
"""

def make_pretty(func):
    def inner():
        print("I got decorated")
        func()
    return inner

def ordinary():
    print("I am ordinary")


ordinary() #I am ordinary
pretty = make_pretty(ordinary) # inner
pretty() # I got decorated\n I am ordinary


"""
@make_pretty
def ordinary():
    print("I am ordinary")

is equivalent to
   
def ordinary():
    print("I am orindary")
ordinary = make_pretty(ordinary)
"""



#divide(2,0) # ZeroDivisionError
from datetime import datetime
from time import time
def smart_divide(func):
    def inner(a,b):
        print("I am going to divid", a , "and", b)
        if b == 0:
            print("Whoops! cannot divide by 0")
            return
        t1 = time()
        res = func(a,b)
        t2 = time()
        print(f'Function (func.__name__!r) executed in {(t2-t1):.4f}s')
        return res
    return inner

@smart_divide
def divide(a,b):
    return a/b

divide(8,2)
divide(1010200023403204234,0.13)
#divide 2/0 -->

#####
"""
star decorator 
star(printer)
***********
msg
***********
"""
def star(func):
    def inner(*args,**kwargs):
        print("*" * 15)
        func(*args,**kwargs)
        print("*"*15)
    return inner

def percent(func):
    def inner(*args,**kwargs):
        print("%" * 15)
        func(*args,**kwargs)
        print("%"*15)
    return inner

@star
@percent
def printer(msg):
    print(msg)

printer("Hello")


#functool.wraps
from functools import wraps
def a_decorator(func):
    @wraps(func)
    def inner(*args, **kwargs):
        """A wrapper function"""
        #extend some capabilites of func
        func()
    # inner.__name__ = func.__name__
    # inner.__doc__ = func.__doc__
    return inner
@a_decorator
def first_function():
    """This is docstring for first function"""
    print("first function")
@a_decorator
def second_function():
    """This is docstring for second function"""
    print("second function")
print(first_function.__name__) #first_function
print(first_function.__doc__) #
print(second_function.__name__)
print(second_function.__doc__)


#sum('a',2) -> not allowed both arguments should be int
#sum(2,3) -> 5

def sum(a,b):
    """
    add the first argument and second argument
    :param a: int
    :param b: int
    :return: int
    """
    return a + b

##sum and decorate the same on validating the integer input
