### stdin - input
### stdout - print

name = input("enter your name:")
print(name)

###python comments

#this is just a text that won't be executed - single line comment

"""
this is just a text that won't be executed
as it's a multiline comment
"""