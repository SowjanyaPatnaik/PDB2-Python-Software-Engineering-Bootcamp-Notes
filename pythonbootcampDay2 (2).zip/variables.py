"""
Varaibles - use to store data
and they take memory based on the type of value

syntax: <variable_name> = <value>

you do not have to explicitly specify the data type of the variable

python is called dynamically typed programming language.

c language: int a = 8
"""

num = 8 #4 bytes
name = "sugumar"
num = 10000

true =  True
false = False

print(num)
print(name)

"""
variable name is known as identifier

default identifiers ( set of keywords used by python itself which we can't use as variables )

print = "Test"
print(print)


print, set, int, str, frozenset, True, False

custom identifiers - rules

- name of the variables must always start with either a letter or an _. For example, _name, age, num, _num
- name of the variable cannot start with a number. for example, 9number is not a valid variable
- name of the variable cannot have any special characters, 
    they can have only alphanumeric characters and underscore
- case sensitive
"""
num = 100
print(id(num))
NUM = 1000
print(id(NUM))

###multiple assignment
#assigning same value to multiple variable
x = 100
print(x)

y = 100
print(y)

z = 100
print(z)

x = y = z = 100
print(x)
print(y)
print(z)

##single line multiple variable with different value
first_name = "sugumar"
last_name = "v"
age = 30

first_name,last_name,age = "sugumar","v",30
print(first_name)
print(last_name)
print(age)

#car
car_brand,car_price,car_mileage = "audi","80L","6kmpl"

#operation of varibles
a = 80
a = a*100
print(a)
a = "sugumar"
print(a)

#### a , b swap the value
a,b,c = 10,9,8
print("a is:",a)
print("b is:",b)
print("c is:",c)

#swap
a,b,c = c,a,b
print("after swap a is:",a)
print("after swap b is:",b)
print("after swap c is:",c)


first_name,last_name = "sugumar","v"
full_name = first_name + last_name
print(full_name)

x,y = 10,9
z = x+y
print(z)

print(first_name+str(x))

###reserved keywords which could not be used as variables - 33
"""
False               class               from                or
None                continue            global              pass
True                def                 if                  raise
and                 del                 import              return
as                  elif                in                  try
assert              else                is                  while
async               except              lambda              with
await               finally             nonlocal            yield
break               for                 not                 
"""

"""
task1 : get the input of firstname, lastname, age and print "Welcome first_name+last_name, and your age is age"
"""

first_name = "sugumar"
last_name = "v"
age =30

print("welcome " + first_name + " " + last_name + ", your age is " + str(age))