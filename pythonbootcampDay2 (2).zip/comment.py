"""
We are writing a simple program here
First print statement
This is a multiple line comment
"""

print("hello team")

#second print statement
print("How are you all?")

print("Welcome to Python Bootcamp") #third print statement

print("comment") #fourth print statement

print("#fifth print statement")