"""
comprehension - special type of pythonic syntax to have the loop in single line.

list comprehension
dictionary comprehension
set comprehension
generator comprehension


Nested comprehension


list comprehension: [<Expr> for <item> in <iterable> if <condition>]
"""

my_list = [1,2,3,4,5,6,7,8,9,10]

"""
filter even number and plus one to it 

[3,5,7,9,11]
"""

new_list = []
for number in my_list:
    if number % 2 == 0:
        new_list.append(number+1)

new_list = [ number+1 for number in my_list if number % 2 == 0 ]

"""
dictionary comprehension

{<key>:<value>} for <item> in <iterable> if <condition>}
"""

persons = [
    {
        "name":"Alice",
        "age":30,
        "title": "Data Scientist"
    },
    {
        "name":"Bob",
        "age":35,
        "title": "Data Engineer"
    },
    {
        "name":"Chris",
        "age":33,
        "title": "ML engineer"
    }
]

# to get all the employees having their title contains the string "Data",so , we call them "Data Employees"
# {"Alice":"Data Scientist","Bob":"Data Engineer"}
data_employees = {}
for p in persons:
    if 'Data' in p["title"]:
        data_employees[p['name']] = p['title']

data_employees = {p['name']:p['title'] for p in persons if 'Data' in p['title']}

#set comprehension
#{<expr> for <item> in <iterable> if <condition>}

data_employees_set = set()
for p in persons:
    if 'Data' in p['title']:
        data_employees_set.add(p['name'])

data_employees_set = {p['name'] for p in persons if 'Data' in p['title']}

#generator comprehension

# generator for the even numbers
def even_generator(numbers):
    for n in numbers:
        if n % 2 == 0:
            yield int(n/2) #2/2 = 1, 4/2 = 2, 6/2 = 3, 8/2 = 4, 10/2 = 5

eg = even_generator(my_list)

while True:
    try:
        print(next(eg))
    except StopIteration:
        break

#(<expr> for <item> in <iterable> if <condition>)

eg = (int(number/2) for number in my_list if number%2 == 0)
print(type(eg))
while True:
    try:
        print(next(eg))
    except StopIteration:
        break


"""
Nested comprehension
"""

# we want to print multiplication table from 1 to 10
"""
1*1 = 1
1*2 = 2

"""
for row in range(1,10):
    for col in range(1,row+1):
        print(f'{col}*{row}={row*col} \t',end="")
    print("")

print("===============")
print("\n".join(["".join([f'{row}*{col}={row*col} \t' for col in range(1,row+1)]) for row in range(1,10)]))

firstname = ["sugumar","alice","bob"]
lastname = ["v","m","n"]

#list comprehension = [(sugumar,v),(alice,m),(bob,n)]

print([(fn,ln) for fn in firstname for ln in lastname])

print([(firstname[i],lastname[i]) for i in range(0,len(firstname))])


test_list = [ ('a',1), ('b',2), ('c',3), ('d',4)]
sort_order = ['c','b','a','d']

#[('d',4),('c',3),('b',2),('a',1)]

res = [
    y for x in sort_order for y in test_list if y[0] == x
]

print(res)