"""
Generators - that allows you to create your iterator function.

a generator is somewhat a function that returns an iterator object with the succession of values
rather than a single item.

A yield statement, rather than a return statement, is used in a generator function.

The difference is that, although a return statement terminates a function completely, a yield statement
pauses the function while storing all of its states and then continues from there on subsequent calls

Normal Function: start and Finish on return

Generators: start -> yield ( yield the value, Pause(save the state) ) and exist -> FInish

"""

def PowerTwoGen(max=0):
    n = 1
    while n < max:
        yield 2 ** n
        n = n + 1

a = PowerTwoGen(10)
for i in a:
    print(i)


def fib(max):
    p,q = 0,1
    while p < max:
        yield p
        p,q = q,p+q

n = int(input("enter the number up to which you wish the Fibonacci series to be printed:\n"))
x = fib(n)
for i in x:
    print(i)

"""
iterators                                              generators
next(),iter()                                             yield

classes                                                   functions

every iterator                                            every generator is 
is not a generator                                        an iterator

complex implementation                                     simpler to code 

less memory efficient                                       more memory efficient

No local variables                                          all the local variables are stored
are used in iterators                                        before the yield statement.



"""

