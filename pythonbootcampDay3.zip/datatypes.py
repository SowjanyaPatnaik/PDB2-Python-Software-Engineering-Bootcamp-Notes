"""
Data type: defines the type of the variable, whether it could be a numeric variable,
string variable, tuple, dict, list
"""

"""
Mutable and Immutable

Mutable - which can be changed.
List
Dictionary
Set

Immutable - once the variable is defined, the value of it cannot be changed.
Numeric
String
Tuple
"""

"""
Numeric: long, float, int, binary, octal, hexadecimal, complex
"""

#in python3, integer data type is not having upper limit so both int and long will have
#the same type int
inum = 8
print("Data type of the variable is",type(inum))

lnum = 100242342342343
print("Data type of the variable is",type(lnum))

fnum = 34.45
print("Data type of the variable is",type(fnum))

cnum = 3 + 4j
print("Data type of the varibale is",type(cnum))

bnum = 0b101 #integer equivalent
print("Data type of the varibale is",type(bnum))
print("Value of the varibale is",bnum)

onum = 0o32
print("Data type of the varibale is",type(onum))
print("Value of the varibale is",onum)

hnum = 0xff
print("Data type of the varibale is",type(hnum))
print("Value of the varibale is",hnum)


"""
string - immutable
"""

s = "This is a string"
print(s)
print(type(s))


s1 = """this is a string with 
multiline"""
print(s1)
print(type(s1))

"""
s = "some value"
     0123456789
            -3-2-1
s[9] == s[-1]
"""

"""formatting"""

first_name = "sugumar"
last_name = "v"
welcome_msg = "Welcome to the bootcamp"

greetings = f"Hi {first_name} {last_name}, {welcome_msg}"
print(greetings)

first_name = "Test"
last_name = "User"
greetings2 = "Hi %s %s, %s and you'r id is %d" % (first_name, last_name, welcome_msg, 2342)
print(greetings2)

greetings3 = "Hi {f} {l}, {wm}".format(f=first_name,
                                      l=last_name,
                                    wm=welcome_msg)
print(greetings3)


greetings4 = "Hi {1} {2}, {3}".format(first_name,last_name,welcome_msg,"testasdfkj")
print(greetings4)

"""slicing
(start, stop, step)
inclusive of start
and exclusive of stop
"""

str3 = "Mathematics Science"
       #012345678910
           #h m t i(ex)
print(str3[11:15])###

print(str3[::-1])

"""
s = "test"

s[::-1] 
start=0, step=-1

start+step = 0-1 = -1+-1 = -2+-1 = -3+-1 = -4

-1-2-3-4 
t s e t
"""