'''

Task1: Take a stdin input and type cast to number and square it and stdout it
Task2: Take a stdin of year of date of birth and subtract it from the current year and stdout the age

Edited<https://teams.microsoft.com/l/message/19:G9fHEXyLjHEuG0QYfzfWoPMWW1sUA_ctEJ2dI5cBtzs1@thread.tacv2/1655861206200?tenantId=fd958fff-96e9-4da8-91d5-1c885155e361&amp;groupId=69690ae2-73b1-4037-a72e-e0f1dbc26c73&amp;parentMessageId=1655861206200&amp;teamName=PDB2 Python Software Engineering Bootcamp - Takeo&amp;channelName=General&amp;createdTime=1655861206200>
'''
num = input("enter the number: ")
print(int(num)**2) # num * num

current_year = 2022
dob = input("enter the year of birth: ")
age = current_year-int(dob)
print("Age is", age)

## print age as a binary

age_in_binary = "{0:b}".format(age)
print("Age in binary is", age_in_binary)

age_in_octal = "{0:o}".format(age)
print("Age in octal is", age_in_octal)

age_in_hexadecimal = "{0:x}".format(age)
print("Age in hexadecimal is", age_in_hexadecimal)