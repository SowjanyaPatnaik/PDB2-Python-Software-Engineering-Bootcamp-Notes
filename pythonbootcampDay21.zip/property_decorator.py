class Portal:
    def __init__(self):
        self.__name = ""

    @property
    def name(self):
        return self.__name

    @name.setter
    def name(self,val):
        self.__name = val

    @name.deleter
    def name(self):
        del self.__name


p = Portal()
p.name = "Sugumar"
print(p.name)
del p.name
print(p.name)

####write a class named Alphabet and getter, setter and delete of attribute named value