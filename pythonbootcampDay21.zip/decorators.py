"""
decoratos - help to add functionality to an existing code.

Sum - implemented

extend the function without changing its implementation, then we will use decorators

"""

def first(msg):
    print(msg)

first("hello")

second = first
second("hello")

third = first
third("hello3")

def inc(x):
    return x + 1

def dec(x):
    return x -1

def operate(func,x):
    result = func(x)
    return result

print(operate(inc,5))
print(operate(dec,6))

def is_called():
    def is_returned():
        print("Hello")
    return is_returned

new = is_called()
print(new())

"""
function objects can hold different names - different variables can be assigned to the same function
we could pass function as an argument to another function
we could return an function from another function
"""

def make_pretty(func):
    def inner():
        print("I got decorated")
        func()
    return inner

def ordinary():
    print("I am ordinary")


ordinary() #I am ordinary
pretty = make_pretty(ordinary) # inner
pretty() # I got decorated\n I am ordinary


"""
@make_pretty
def ordinary():
    print("I am ordinary")

is equivalent to
   
def ordinary():
    print("I am orindary")
ordinary = make_pretty(ordinary)
"""



#divide(2,0) # ZeroDivisionError
from datetime import datetime
from time import time
def smart_divide(func):
    def inner(a,b):
        print("I am going to divid", a , "and", b)
        if b == 0:
            print("Whoops! cannot divide by 0")
            return
        t1 = time()
        res = func(a,b)
        t2 = time()
        print(f'Function (func.__name__!r) executed in {(t2-t1):.4f}s')
        return res
    return inner

@smart_divide
def divide(a,b):
    return a/b

divide(8,2)
divide(1010200023403204234,0.13)
#divide 2/0 -->

#####
"""
star decorator 
star(printer)
***********
msg
***********
"""
def star(func):
    def inner(*args,**kwargs):
        print("*" * 15)
        func(*args,**kwargs)
        print("*"*15)
    return inner

def percent(func):
    def inner(*args,**kwargs):
        print("%" * 15)
        func(*args,**kwargs)
        print("%"*15)
    return inner

@star
@percent
def printer(msg):
    print(msg)

printer("Hello")


#functool.wraps
from functools import wraps
def a_decorator(func):
    @wraps(func)
    def inner(*args, **kwargs):
        """A wrapper function"""
        #extend some capabilites of func
        func()
    # inner.__name__ = func.__name__
    # inner.__doc__ = func.__doc__
    return inner
@a_decorator
def first_function():
    """This is docstring for first function"""
    print("first function")
@a_decorator
def second_function():
    """This is docstring for second function"""
    print("second function")
print(first_function.__name__) #first_function
print(first_function.__doc__) #
print(second_function.__name__)
print(second_function.__doc__)


#sum('a',2) -> not allowed both arguments should be int
#sum(2,3) -> 5

def sum(a,b):
    """
    add the first argument and second argument
    :param a: int
    :param b: int
    :return: int
    """
    return a + b

##sum and decorate the same on validating the integer input

"""
to check if the given array is monotonic 

an array A is monotonic if it' increasing for all i <= j, A[i] <= A[j]
                               decreasing for all i <= j, A[i] >= A[j]

input = [6,5,4,4]

input  = [5,15,20,10]


i = 0
while i < len(input):
    if input[i] >= input[i+1]:
        pass
    elif input[i] <= input[i+1]:
        pass
    else:
        print("not a monotonic")
        break
    i = i+1
print(" it's monotonic ")
"""

"""
@property
@staticmethod
@classmethod
"""

"""
@property - a pythonic way to use getters and setters in object-oriented programming.
"""

class Celsius:
    def __init__(self,temperature=0):
        self.temperature = temperature

    def to_farenheit(self):
        return (self.temperature * 1.8) + 32

obj1 = Celsius()
#set the temperature
obj1.temperature = 37
#get the temperature
print(obj1.temperature)
print(obj1.to_farenheit())

# implement the restriction that any object temperature cannot be below -273.15 degree celsius
class Celsius:
    def __init__(self,temperature=0):
        self.set_temperature(temperature)

    #setter method
    def set_temperature(self,value):
        if value < -273.15:
            raise ValueError("Temperature below -273.15 is not possible")
        self._temperature = value

    #getter method
    def get_temperature(self):
        return self._temperature

    def to_farenheit(self):
        return (self.get_temperature() * 1.8) + 32

obj2 = Celsius(37)
print(obj2.get_temperature())
print(obj2.to_farenheit())
# obj2.set_temperature(-300)
# print(obj2.to_farenheit())

class Celsius:
    def __init__(self,temperature=0):
        self.temperature = temperature

    def to_farenheit(self):
        return (self.temperature * 1.8) + 32

    #getter
    def get_temperature(self):
        print("Getting Value...")
        return self._temperature

    #setter
    def set_temperature(self,value):
        print("Setting Value...")
        if value < -273.15:
            raise ValueError("Temperature below -273.15 is not possible")
        self._temperature = value

    temperature = property(get_temperature, set_temperature)


obj3 = Celsius(37)
print(obj3.temperature)
print(obj3.to_farenheit())
obj3.temperature = -300


class Portal:
    def __init__(self):
        self.__name = ""

    @property
    def name(self):
        return self.__name

    @name.setter
    def name(self,val):
        self.__name = val

    @name.deleter
    def name(self):
        del self.__name


p = Portal()
p.name = "Sugumar"
del p.name
print(p.name)