class Student:
    def __init__(self,first_name,last_name):
        self.first_name = first_name
        self.last_name = last_name

scott = Student("Scott","Robinson")
print(scott.first_name,scott.last_name)

class Student:
    def __init__(self,first_name,last_name):
        self.first_name = first_name
        self.last_name = last_name

    @classmethod
    def from_string(cls,name_str):
        first_name,last_name = map(str,name_str.split(" "))
        student = cls(first_name,last_name)
        return student

    @classmethod
    def from_json(cls,json_obj):
        first_name,last_name = json_obj["first_name"],json_obj["last_name"]
        student = cls(first_name,last_name)
        return student

scott =  Student.from_string("Scott Robinson")
print(scott.first_name,scott.last_name)

scott2 = Student.from_json({"first_name":"Scott","last_name":"Robinson"})
print(scott.first_name,scott.last_name)

##Class EligibletoVOTe -> age - age can be directly given or
# it can be calculate from the date of birth or it
## could be calculated from the parents age

class Student:
    def __init__(self, first_name, last_name):
        self.first_name = first_name
        self.last_name = last_name

    @staticmethod
    def is_full_name(name_str):
        names = name_str.split(" ")
        return len(names) > 1

print(Student.is_full_name("Scott Robinson"))
print(Student.is_full_name("Scott"))

s = Student("test", "test1")
print(s.is_full_name("Test"))