"""
inheritance -  The method of inheriting the properties of parent class into child class
is known as inheritance.

Advantages:
- Code reusability
- Represent a real world relationship between parent class and child class
- Transtive is nature, if a child class inherits properties from a parent class, then all other sub-classes
of the child class will also inherit the properties of the parent class


"""

class Parent():
    def first(self):
        print("first function")

class Child(Parent):
    def second(self):
        print("second function")

ob = Child()
ob.first()
ob.second()

class Parent:
    def __init__(self,fname,age):
        self.firstname = fname
        self.age = age

    def view(self):
        print(self.firstname, self.age)

class Child(Parent):
    def __init__(self, fname,age):
        super(Child,self).__init__(fname,age)
        # Parent.__init__(fname,age)
        self.lastname = "ed"
    def view(self):
        print(self.firstname,self.age,self.lastname)

ob1 = Child("Sugumar",29)
ob1.view()


class Person(object):
    #__init__ is known as the constructor
    def __init__(self,name,idnumber):
        self.name = name
        self.idnumber = idnumber

    #display method
    def display(self):
        print(self.name)
        print(self.idnumber)

class Employee(Person):
    def __init__(self,name,idnumber,salary,post):
        self.salary = salary
        self.post = post

        #invoking the __init__ of the parent class
        super(Employee,self).__init__(name,idnumber)
        #Person.__init__(self,name,idnumber)

    def display(self):
        super(Employee,self).display()
        print(self.salary)
        print((self.post))

a = Employee("Dinesh",886012,20000,"Intern")
a.display()

"""
type of inheritance
- single
- multiple
- multilevel
- hierarchial
"""

"""
Single Inheritance - When a child class inherits only a sinlge parent class
"""

class Parent(object):
    def func1(self):
        print("this is a function one")
class Child(object):
    def func2(self):
        print("this is a function 2")

ob2 = Child()
ob.func1()
ob.func2()

"""
Multiple Inheritance - When a child class inherits from more than one parent class
"""
class Parent1:
    def func1(self):
        print("this is function 1")
class Parent2:
    def func2(self):
        print("this is function 2")
class Child(Parent1,Parent2):
    def func3(self):
        print("this is function3")
ob4 = Child()
ob4.func1()

"""
Multilevel Inheritance: when a child class becomes a parent class for another child class

GrandFather -> Father -> Child 


Hierarchial Inheritance:

GrandFather, GrandMother -> Father, Mother -> Child

Class GrandFather:
  pass
  
Class Father(GrandFather):
   pass

class Child1(Father)
class Child2(Father)

Hybrid - combination of multiple inheritance and other inheritances

class GrandFather
class GrandMother
class Father(GrandFather, GrandMother)
class Child(Father)
"""


import math

class Shape:
    def __init__(self,color="black",filled=False):
        self._color = color
        self.__filled = filled

    def get_color(self):
        return self._color

    def set_color(self,color):
        self._color = color

    def get_filled(self):
        return self.__filled

    def set_filled(self,filled):
        self.__filled = filled


class Rectangle(Shape):
     def __init__(self,length,breadth):
         super(Rectangle,self).__init__()
         self.__length = length
         self.__breadth = breadth
     def get_length(self):
         return self.__length
     def get_breadth(self):
         return self.__breadth
     def set_length(self,length):
         self.__length = length
     def set_breadth(self,breadth):
         self.__breadth = breadth
     def get_area(self):
         return self.__breadth * self.__length
     def get_perimeter(self):
         return 2 * (self.__length + self.__breadth)

r1 = Rectangle(10.5,2.5)
r1.get_area()
r1.get_perimeter()
r1.get_color()

"""
write an program  with the real world problem

ecommerce, banking, music library, elevator,

ecommerce:

class Product():
    def setprice()
    def getprice()

class Smartphone(Product):
    def getbrand()


Elevator

class Elevator:
    def current_position()
    def weight()
    
class Apartment(Elevator)
class Hosptial(Elevator)
class Mall(Elevator)


Polymorphism
decorators
comprehension

2 class - series of solving python problems
linked list
sorting
searching
BT
BST
Trees

Program1: Sort Characters by frequency

string: csestack

output: aektccss / ccssetak

hint: dictionary

26 characters


freq = {}
for i in s:
    if freq.get(i): freq[i] += 1
    else: freq[i] = 1

out = ""
for k,v in freq.items():
    out  += (k*v)
    
hello
{"h":1,"e":1,"l":2,"o":1}

"""