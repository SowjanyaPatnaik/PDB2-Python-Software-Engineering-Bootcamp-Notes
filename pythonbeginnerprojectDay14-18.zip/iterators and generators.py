"""
iterators and geneartors - tools for iterating over sequences or traversing

iterator - an iterator is an object used to iterate over iterable objects
such as list, tuples, dictionaries and sets
An object is called iterable if we can get an iterator from it or loop over it.

Numbers = [2,6,8,10,12]

Numbers = 2 #not iterable
String1 = "sugumar"

In simple, an iterator is just an object that can be iterated on.

A python iterator object must implement two specific methods,

__iter__() or iter() and
__next__() or next()

which are referred to collectively as the iterator protocol

iter() or __iter__(): returns an iterator for the supplied object. It generates a thing that can be
iterated one element ata time.

iter(object, sentinel)
object is mandatory - AN object whose iterator needs to be created (list, set, tuple)
sentinel is optional - Special Value that represents the end of the sequence.

next(iterator, default)
iterator - retrieves the next item for the iterator
default  this value is returned if the iterator is exhausted ( not tried, but no next item to retrieve )

"""

list1 = [25,78,'coding','is','<3']
a = iter(list1)
# print(a)
# print(next(a)) #1st element
# print(next(a))
# print(next(a))
# print(next(a))
# print(next(a))
# print(next(a,"end of list"))
# print(next(a))

while True:
    try:
        print(next(a))
    except StopIteration:
        break


class MyNumbers:
    def __iter__(self):
        self.a = 1
        return self

    def __next__(self):
        if self.a <= 5:
            x = self.a
            self.a = self.a + 1
            return x
        else:
            raise StopIteration

myclass = MyNumbers()
myiter = iter(myclass)
for x in myiter:
    print(x)


### power of two  n=4 , 2,4,8,16, n=5, 2,4,8,16,32

class PowerTwo:
    def __init__(self,max=0):
        self.max = max

    def __iter__(self):
        self.n = 1
        return self

    def __next__(self):
        if self.n <= self.max:
            result = 2 ** self.n
            self.n += 1
            return result
        else:
            raise StopIteration

powerof2obj = PowerTwo(10)
i =  iter(powerof2obj)
for j in i:
    print(j)