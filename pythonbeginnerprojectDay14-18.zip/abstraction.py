"""
abstraction:
process of handling complexity by hiding unnecessary information from the user.

real world example:
    social platforms: fb, twitter, linkedin, snapchat, whatsapp

abstraction in python:
    in python, abstraction is achieved by using abstract classes and methods

abstract method:
    an  abstract method is method that is declared, but does not contain implementation


class Employee:

    def employeeId(self):
        raise NotImplementedError

class ABCEmployee(Employee):

    def employeeId(self):
        return "ABC123"

class XYZEmployee(Employee):

    def employeeId(self):
       return "XYZ123"

An abstract method in a base class identifies the functionality that should be
implemented by all it's subclasses. However, since the implementation of an abstract method
would differ from one subclass to other, often the method comprises just a pass statement.

Every subclass of the base class will ride this method with it's implementation.

A class containing abstract methods is called abstract class.

Python provides the abc module to use the abstraction in the python program, syntax as

from abc import ABC
class <className>(ABC)


shape - abstractclass

rectangle, circle - methods of computing area and perimeter
"""

from abc import ABCMeta, abstractmethod

class Shape(object, metaclass=ABCMeta):
    def __init__(self,shapeType):
        self.shapeType = shapeType
    @abstractmethod
    def area(self):
        pass
    @abstractmethod
    def perimeter(self):
        pass
    @abstractmethod
    def volume(self):
        pass
    @abstractmethod
    def perivolume(self):
        pass

class Rectangle(Shape):
    def __init__(self,length,breadth):
        Shape.__init__(self,'Rectangle')
        self.length = length
        self.breadth = breadth
    def area(self):
        return self.length * self.breadth
    def perimeter(self):
        return 2 * (self.length + self.breadth)
    def volume(self):
        pass


class Circle(Shape):
    pi = 3.14
    def __init__(self,radius):
        Shape.__init__(self,"Circle")
        self.radius = radius
    # def area(self):
    #     return round(Circle.pi * (self.radius*self.radius), 2)
    # def perimeter(self):
    #     return round(2 * Circle.pi * self.radius, 2)


# s = Shape("Rectangle")

rectangle = Rectangle(30,15)
print(rectangle.area())
print(rectangle.perimeter())
print(rectangle.volume())
# circle = Circle(5)
# print(circle.area())
# print(circle.perimeter())
#

"""
abstraction -

- Vehilce, type - two wheeler, three wheeler, four wheeler, HexaWheeler

Class Vehicle
    @
    def wheel_type()
    def brand_type()

- Human, height, weight, bmi, familyname,
"""