class Counter:
    def __init__(self):
        self.__current = 0

cnt = Counter()
print(cnt.__current)