"""
fundamental oops concets

encapsulation
abstraction
polymorphism
inheritance

"""

"""
encapsulation: is one of the four fundamental concepts in oops.

packaging of data and functions that work on that data within a single object. this is also known as
information hiding

A class is an example of encapsulation. A class bundles data and methods in to a single unit.

And a class provides the access to its attributes via methods.

The idea of information hiding is that
    - if you an attribute that isn't visible to the outside, you can control the access to it's value to make sure that
    object is always have a valid state.

"""



# class Counter1:
#     def __init__(self):
#         self.current = 0
#     def increment(self):
#         self.current += 1
#     def value(self):
#         return self.current
#     def reset(self):
#         self.current = 0
#
# counter = Counter1()
# counter.increment()
# counter.increment()
# counter.increment()
# print(counter.value()) #3
#
# counter = Counter1()
# counter.increment()
# counter.increment()
# counter.current = -999
# print(counter.value())

#how do you prevent the current attribute from modifying outside the class ?

#private attributes

"""
Private attributes can be only accessible from the methods of the class. In other words, they 
cannot be accessible from outside of the class

Python doesn't have a concept of private attributes. In other words, all attributes are accessible 
from the outside of the class

by convention, we can define a private attribute by prefixing a single underscore (_)
"""
#
# class Counter2:
#     def __init__(self):
#         self._current = 0
#
#     def increment(self):
#         self._current += 1
#
#     def value(self):
#         return self._current
#
#     def reset(self):
#         self._current = 0
#
#
# counter = Counter2()
# counter.increment()
# counter.increment()
# counter._current = -9
# print(counter._current)

#name-mangling.
class Counter3:
    def __init__(self):
        self.__current = 0

    def increment(self):
        self.__current += 1

    def value(self):
        return self.__current

    def reset(self):
        self.__current = 0

cnt = Counter3()
# cnt.__current
#python will automatically change the name of the __attribute to _class__attribute
cnt.increment()
cnt.increment()
print(cnt._Counter3__current)

cnt._Counter3__current = -9
print(cnt._Counter3__current)
#by doing the name hangling, we cannot access the __attribute directly from the outside of the class
#like instance.__attribute, but you can still access it using instance._class__attribute


"""
Summary:
- Encapsulation is the packing of data and methods into a class so that you can hide the information
and restrict access from outside
- prefix an attribute with a single underscore (_) to make it private by convention
- prefix an attribute with double underscores (__) to use the name hangling


task: try creating a class with private variable and function and
name hangline varibale and function.

class <>:
    _attr
    __attr
    _func()
    __func()
"""



class Employee:
    __employer = "ABC"
    def __init__(self,first_name,last_name,dob):
        self.first_name = first_name
        self.last_name = last_name
        self.__year_of_birth = dob
        self.__salary =  5000

    def __calculate_age(self):
        return 2022 - self.__year_of_birth

    def display_data(self):
        print(f"{self.first_name}, {self.last_name}, {self.__calculate_age()}, {self.__salary}")

# emp1 = Employee("Sugumar","V",1992)
# emp1.display_data()
#
# print(emp1._Employee__salary)
# print(emp1._Employee__calculate_age())

# print(Employee._Employee__employer)q

"""
abstraction - abstraction + encapsulation.

if you're pressing a remote key, it's changing the channels in TV.
you're inserting the car key, the engine starts.

process of hiding the real implementation of the an application from the user and emphasizing only on usage of it
"""



"""
Matrix Addition

X = [[1,2,3],[4,5,6],[7,8,9]]

Y = [[9,8,7],[6,5,4],[3,2,1]]

X+Y

[[10,10,10],[10,10,10],[10,10,10]]

[[1,2,3,4],[5,6,7]] = 2 * 4
[[2,3,4],[5,6,7]] = 2 * 3

- We cannot add matrices of different order. 
Matrix addition takes place when the order of two matrices are the same

Class MatrixAddition:
   def __init__(self,a,b):
   
   def validate_order(self):
        a_rows = len(self.a)
        a_columns = max[len(each) for each in self.a]
        b_rows = len(self.b)
        b_columns = max[len(each) for each in self.b]
        if (a_rows == b_rows == c_rows) and (b_columns === a_columns == c_columns) :
            return True
        return False
   
   def add()
      if validate_order():
         do add
      raise Exception("Not of same order")
"""


"""


"""