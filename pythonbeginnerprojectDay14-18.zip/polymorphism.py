"""

polymorphism - taking more than one form.

It means that the same function name can be used for different types.

polymorphism in python could be done by

with functions and objects
with class methods
with inheritance
"""
class BMW():
    def type(self):
        print('car')
    def color(self):
        print("silver")
    def size(self):
        print("small")
class ISuzu():
    def type(self):
        print("truck")
    def color(self):
        print("gold")
    def size(self):
        print("medium")

def func(obj):
    obj.type()
    obj.color()
    obj.size()

obj_bmw = BMW()
obj_isuzu = ISuzu()
func(obj_bmw)
func(obj_isuzu)

#function overloading will not work in python
def volume(a, b):
    return a*b

def volume(a,b,c):
    return a*b*c

# volume(2,3)

###
class India():
    def capital(self):
        print("New Delhi")
    def language(self):
        print("Hindi and English")
class USA():
    def capital(self):
        print('Washington D.C.')
    def language(self):
        print('English')
obj_ind = India()
obj_usa = USA()
for country in (obj_ind,obj_usa):
    country.capital()
    country.language()


"""
Polymorphism in python defines methods in the child class that have the same name as the method in the 
parent class. In inheritance, the child class inherits the methods from the parent class. Also, it is possible
to modify the method in a child class that it has inherited from the parent class

The process of re-implementing a method in the child class is known as method overriding.
"""

class Bird:
    def intro(self):
        print("There are different types of birds")
    def flight(self):
        print("Most of the birds can fly but some cannot")
class Parrot(Bird):
    def flight(self):
        print("Parrots can fly")
class Penguin(Bird):
    def flight(self):
        print("Penguins do not fly")
obj_bird = Bird()
obj_parr = Parrot()
obj_peng = Penguin()
obj_bird.intro()
obj_bird.flight()
obj_peng.intro()
obj_peng.flight()
obj_parr.intro()
obj_parr.flight()





