"""
Data type: defines the type of the variable, whether it could be a numeric variable,
string variable, tuple, dict, list
"""

"""
Mutable and Immutable

Mutable - which can be changed.
List
Dictionary
Set

Immutable - once the variable is defined, the value of it cannot be changed.
Numeric
String
Tuple
"""

"""
Numeric: long, float, int, binary, octal, hexadecimal, complex
"""

#in python3, integer data type is not having upper limit so both int and long will have
#the same type int
inum = 8
print("Data type of the variable is",type(inum))

lnum = 100242342342343
print("Data type of the variable is",type(lnum))

fnum = 34.45
print("Data type of the variable is",type(fnum))

cnum = 3 + 4j
print("Data type of the varibale is",type(cnum))

bnum = 0b101 #integer equivalent
print("Data type of the varibale is",type(bnum))
print("Value of the varibale is",bnum)

onum = 0o32
print("Data type of the varibale is",type(onum))
print("Value of the varibale is",onum)

hnum = 0xff
print("Data type of the varibale is",type(hnum))
print("Value of the varibale is",hnum)


"""
string - immutable
"""

s = "This is a string"
print(s)
print(type(s))


s1 = """this is a string with 
multiline"""
print(s1)
print(type(s1))

"""
s = "some value"
     0123456789
            -3-2-1
s[9] == s[-1]
"""

"""formatting"""

first_name = "sugumar"
last_name = "v"
welcome_msg = "Welcome to the bootcamp"

greetings = f"Hi {first_name} {last_name}, {welcome_msg}"
print(greetings)

first_name = "Test"
last_name = "User"
greetings2 = "Hi %s %s, %s and you'r id is %d" % (first_name, last_name, welcome_msg, 2342)
print(greetings2)

greetings3 = "Hi {f} {l}, {wm}".format(f=first_name,
                                      l=last_name,
                                    wm=welcome_msg)
print(greetings3)


greetings4 = "Hi {1} {2}, {3}".format(first_name,last_name,welcome_msg,"testasdfkj")
print(greetings4)

"""slicing
(start, stop, step)
inclusive of start
and exclusive of stop
"""

str3 = "Mathematics Science"
       #012345678910
           #h m t i(ex)
print(str3[11:15])###

print(str3[::-1])

"""
s = "test"

s[::-1] 
start=0, step=-1

start+step = 0-1 = -1+-1 = -2+-1 = -3+-1 = -4

-1-2-3-4 
t s e t
"""

s = "This is the test string"
print(dir(s)) # dir will give the list of supported methods and magic methods of that respective object


num9 = 9
print(dir(num9))
### try all the me

"""
Tuple - immutable which means it cannot be changed. It's an ordered collection of elements enclosed in a
round brackets and separated by commas.
"""

tuple1 = (1,2,3,4)
print(tuple1)

tuple2 = tuple((1,2,3,4))
print(tuple2)

tuple3 = (1,2,3,4,)
print(id(tuple3))

print(tuple3[0], tuple3[1])

print(tuple3[-1], tuple3[-2])

# tuple3[0] = 9

tuple3 = (9,2,3,4,)
print(id(tuple3))

"""
slicing ( start, stop, step )
"""

tuple4 = (1,2,3,4,5,6,7,8,9,10)
          # 0 1 2 3 4 5 6 7 8 9 ( len -> 10)
#get even numbers from the tuple 4 using slicing
print(tuple4[0:len(tuple4):2])

print(tuple4[0:-1:2])


print(tuple4[1:len(tuple4):2]) # [1:10:2]  -> 2,4,6

print(tuple4[1::2]) #1:10:2

print(tuple4[1:-1:2])

##give the slicing code for getting the last 3 number using positive and negative index

#positive
print(tuple4[7:])
#negative
print(tuple4[-3:])

print(id(tuple4))
print(id(tuple4[::]))

t4 = tuple4[::]
print(id(t4),t4)

tuple4 = (1,2,3,4,5,6,7,8,9,10)
print(id(tuple4),tuple4)

tuple5 = (1,2,3,4,5,6,7,8,9,10,11)
print(id(tuple5),tuple5)

num = 100
num1 = 100
print(id(num),id(num1))

str1 = "this is sugumar"
str2 = "this is sugumar"
str3 = str2.upper()
print(id(str1),id(str2),id(str3),str1,str2,str3)


"""
var = value

var  =  <memory_address_of the value>
var -> 0x234234 -> return value
"""

"""
List - mutable - it can be changed
STACK =  LIFO
"""

l1 = list(("apple","banana","orange"))
print(id(l1),l1)

l2 = ["apple","banana","orange"]
print(id(l2),l2)

l3 = l2
print(id(l3),l3)

l2.append("kiwi") #value based addition
print(l2)

l2.insert(2,"mango") # index based addition
print(l2)

l2.pop()
print(l2)

l2.remove("apple") #values based deletion
print(l2)

l2.pop(1) #index based deletion
print(l2)

print(id(l2),l2)


uv = (1,[23,2342,2398],9, 10) #[[1,2][2,4]]
"""
uv[0] = 1
uv[1] = [23,2342,2398] => uv[1][0] = 23
"""
uv[1][0] = 25 #
print(uv)

uv[1].append("43234")
print(uv)


"""
Dictionary - collection of key and value pairs.
A dictionary doesn't allow the duplicate keys but the values can be duplication

keys are immutable datatype, values can be mutable/immutable datatype

keys can be tuple, str, int

"""

dict1 = dict(name="sugumar",age=30,lastname="v")
print(dict1)

dict2 = {"name":"sugumar","age":30,"lastname":"v"}
print(dict2)

dict3 = {
         ("test1","test2"):["Maths","Science"],
         ("test3","test4"):["Sugumar","v"],
         ("test3","test4"):["Maths","Science"],
         }
print(dict3)

print(dict3.keys())
print(dict3.values())


dict4 = [{
            ("username","password"):("sugumar","*****"),
            ("firstname","lastname"):("sugumar","v"),
            "url":"facebook"
        },
        {
            ("username","password"):("sugumar","*****"),
            ("firstname","lastname"):("sugumar","v"),
            "url":"instagram"
        }]
print(dict4[1].keys())
print(dict4[1].values())

dict5 = {
    "username":"sugumar",
    "password":"****",
    "firstname":"sugumar",
    "lastname":"v"
}

mydict = {"stuName":"Dinesh","stuAge":"30","stuCity":"Agra"}
#accessing values using keys in a dictionary
print(mydict["stuName"]) #-->
print(mydict.get("stuName")) # -- >
print(mydict.get("stuName","Not Given")) #--->
print(mydict.get("Name")) #--> None
print(mydict.get("Name","NA"))#--> NA
# print(mydict["Name"]) #---> error, empty
# mydict["age"] #--> KeyError "age"
mydict.get("age",0) #-->0

"""
changing values in dictionary
"""
mydict = {"stuName":"Dinesh","stuAge":"30","stuCity":"Agra"}
print("befor update, ",mydict)
mydict["stuName"] = "Sugumar"
mydict["stuCity"] = "Chennai"
print("after update, ",mydict)

# mydict["stuNme"] # --> KeyError stuNme
mydict["stuNme"] = "Chris" # set the assignment will work but the calling will not work
mydict["stuNme"] # --> Chris

"""
Adding new key/values in a dictionary
"""
mydict = {"stuName":"Dinesh","stuAge":"30","stuCity":"Agra"}
print("before update, ",mydict)
#update height and weight in the dictionary
#update1 - using [] - single key/value update
mydict["height"] = "185"
#update2 - using update func - allow multiple key/value update
mydict.update({"weight":"80","fatherName":"*****"})
print("after update, ",mydict)

"""delete a key/value pair or dictionary"""
mydict = {"stuName":"Dinesh","stuAge":"30","stuCity":"Agra"}
del mydict["stuName"] # remove entry with the key stuName
mydict.clear() # remove all key-values pairs from mydict
del mydict #delete entire dictionary object


"""
set -  unordered collection of items
unordered - it will come out in a random order
unindexed - we cannot access the elements using index as we do in list and tuples
"""

myset = {"1",2,4,"hello"}

myset.add("hello") # add
myset.remove("hello") #remove
myset.discard("hello") #works like a remove but it will silent fail if the key doesn't exist

"""
add()
remove()
discard()

difference()
intersection()
isdisjoint()
issubset()
union()
symmetric_differene()

"""


"""
Boolean datatype
True
False
"""