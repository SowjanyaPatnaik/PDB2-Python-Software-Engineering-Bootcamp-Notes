lower = 1
upper = 5

for num in range(lower,upper+1): #range(1,6) -> [1,2,3,4,5]
    print("num is,",num)
    if num > 1:
        for i in range(2,num):
            print("i is,", i)
            if (num % i) == 0:
                print("i'm in break")
                break
        else:
            print(num)

for i in range(1,4):#[1,2,3] 1, 2, 3, No break
    print(i)
else:
    print("No Break")

for i in range(1,4): #[1,2,3] 1 terminates the loop
    print(i)
    break
else:
    print("No break")

"""
ctrl + /
"""
count = 0
while (count < 1):
    count = count + 1
    print(count)
    break
else:
    print("No break")

"""
if -> satisifed 
else -> go to else if if condition is not satisfied

for -> fully iterated
else -> go to else if for statement is completely executed

while -> fully iterated
else -> go to else if for statement is completely executed

"""