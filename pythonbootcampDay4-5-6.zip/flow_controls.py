"""
if
if else
if elif else
Nested if
for loop
while loop

break
continue
pass
"""

"""
if conidition:
   <body>
"""

if True:
    print("I'm True")

if False:
    print("I'm False")

###operators
"""
== -> equivalent operator, 8 == 8 - True, 7 == 8 - False
!= -> not equivalent operator, 8 != 8 False, 7 != 8 - True
<
>
<=
>=
%
in
not in
is
"""

# num = int(input("enter the number:"))
# if num % 2 == 0:
#     print("I'm even")
# else:
#     print("I'm odd")
#
# num = int(input("enter the number:"))
# if num > 2:
#     print("I'm greater than 2")
# elif num < 2:
#     print("I'm lesser than 2")
# else:
#     print("I'm equal to 2")

#leap year problem
year = int(input("enter the year:"))

if year % 4 != 0:
    print(f'{year} is not a leap year')
else:
    print(f'{year} is a leap year')

"""
and
0 1 - 0
0 0 - 0
1 1 - 1
1 0 - 0

or
0 1 - 1
0 0 - 0
1 1 - 1
1 0 - 1

"""

date_of_birth = int(input("enter the year of date of birth:"))
age =  2022 - date_of_birth
if date_of_birth > 2000 and age > 18:
    print("I'm 20's kid and I'm eligible to vote")


"""
range(start, stop, step)

range(1,100,1)
#inclusive of start
#exclusive of stop

"""

"""
take an integer input
if it's multiple by 3, print('fizz')
if it's multiple by 5, print('buzz')
if it's multiple by 3 and 5, print('fizzbuzz')


15
fizzbuzz

should not print
fizz
buzz
fizzbuzz
"""

"""
Nested IF
"""

num = 10
if num > 5:
    print("bigger than 5")
    if num <= 15:
        print("between 5 and 15")

"""
for loop - lower bound, upper bound
"""

for i in range(1,100,1):
    if i % 2 == 0:
        print(i)

"""
take an input for upper bound: n
do the for loop for the range of n
separate list of odd, even

example1: range(50)
even numbers: [ 2,4,6,..48 ]
odd numbers: [1,3,5,7,,,49]

2. "this is been one of the finest learners of the bootcamp"
-> to find the largest word in the sentence.
-> print the word, len of the largest word
-> print the index of the word in the sentence

example:
[("learners",8,'31:39'),("bootcamp",8,'47:56')]
"""

"""
nested for loop - display all the prime numbers within an interval
"""

lower = 1
upper = 5

for num in range(lower,upper+1):
    print("num is,",num)
    if num > 1:
        for i in range(2,num):
            print("i is,", i)
            if (num % i) == 0:
                print("i'm in break")
                break
        else:
            print(num)
"""
1,2,3,4,5,6,7,8,9,10

1 -> will not do anything
2 -> 
  range(2,2) -> 2
   2 % 2 
3 ->
   range(2,3) -> 2
"""


